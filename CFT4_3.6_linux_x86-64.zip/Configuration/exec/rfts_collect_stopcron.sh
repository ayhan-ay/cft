#!/bin/ksh
# This script inactivate CFTCRON DATA_COLLECTION_CRON
cftutil inact id=DATA_COLLECTION_CRON, type=cron
cftutil reconfig type=cron