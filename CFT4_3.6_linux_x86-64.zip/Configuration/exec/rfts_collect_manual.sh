#!/bin/ksh

#
# RFTS Collect
# Version 1.6
# v1.6 : collect basket file cfg format
#
# Call :
# rfts_collect.sh RFTSD=<RFTS installation folder> OUTPUT=<archive_output_folder>
# <RFTS installation folder> : Absolute path to the RFTS/x installation folder containing the config subdirectory
# <archive_output_folder> : Output folder for the file created
#

version="1.5"
now=`date +"%Y%m%d-%H%M"`
protocol="rfts_collect.prot"
prog=rfts_collect.sh
email=mbox_rfts_replacement@daimler.com
retention_time=160
format=RFTS_ASSESSMENT_FORMAT_1
#TSI added
MyHOST=`hostname`

usage()
{
        exit_code=${2:-0}
        if [ ! -z "$1" -a _ != "$1" ] ; then
                echo " "
                echo "$prog: $1"
        fi
        cat << EOFUSAGE

Usage: $prog [-h] RFTSD=... OUTPUT=...

Options:
  -h: Display this usage message

Parameters:
  RFTSD:           Absolute path to the RFTS/x Home folder containing the config directory
  OUTPUT:          Output folder for the RFTS/x archive (tar.gz)

EOFUSAGE
        exit $exit_code
} # EOP usage

begin(){

        print
        print "#========================================================="
        print "#====== RFTS collect for Daimler ========================="
        print "#====== Version $version ======================================"
        print "#========================================================="
        print "#========================================================="

}

end_error (){

print "#========================================================="
print "#====== RFTS collect for Daimler ========================="
print "#====== Version $version ======================================"
print "#====== $1"
print "#====== No archive has been generated, exit $2"
print "#========================================================="
exit $2

}

# ====================================================================
# Test Parameters
# ====================================================================
MINARGS=2 # Number of needed arguments (without Options)
          # MINARGS=0 or empty: No arguments needed
MAXARGS=2 # Maximum number of arguments (without Options)
          # MAXARGS<0 or empty: No maximum number of arguments

# Scan Option (starting with '-')
while [ $# -gt 0 ] ; do
        case "$1" in
                -h*|"?") usage _ 0 ;;
                -following_argument) # Example for option followed by an argument
                        shift
                        argument_name="$1"
                ;;
                -*) usage "Unknown option: $1" 1 ;;
                *) break ;;
        esac
        shift
done

[ -z "$MINARGS" -o $# -ge "$MINARGS" ] \
        || usage "You have given me $# argument(s), but I need at least $MINARGS argument(s)" 1
[ -z "$MAXARGS" -o "$MAXARGS" -lt 0 -o $# -le "$MAXARGS" ] \
        || usage "You have given me $# argument(s), but I can only use $MAXARGS argument(s)" 1



# ====================================================================
#                              M A I N
# ====================================================================
# Scan Parameters name=value (starting without '-')
while [ $# -gt 0 ] ; do
        case "$1" in
                RFTSD=*) RFTSD="${1#*=}" ;;
                OUTPUT=*) OUTPUT="${1#*=}" ;;
               *)
                usage "Unknown attribute" 2
                ;;

        esac # case "$1"
        shift
done # while

## Retrieve parameter file
RFTSC=${RFTSD}/config/rfts.cfg

## check if rfts.cfg path is correct and exist otherwise exit
if [ ! -r ${RFTSC} ];then
        end_error "The RFTSx configuration file ${RFTSC} doesn't exist" 1
fi

## Check if we have the RFTS/x ID otherwise exit
rfts_id=`grep -i RFTS_ID ${RFTSC} |cut -d= -f2`
if [ ${rfts_id}. == . ];then
        end_error "The RFTS-ID could not be computed" 1        
fi

## Compute RFTS Work folder
RFTSW=`grep -i RFTS_WORK_PATH ${RFTSC} |cut -d= -f2`
if [ ! -r ${RFTSW} ];then
        end_error "The ${RFTSW} work folder doesn't exist or permission is denied" 1
fi

## Compute RFTS Log folder
RFTSL=${RFTSW}/log
if [ ! -r ${RFTSL} ];then
        end_error "The ${RFTSL} folder doesn't exist or permission is denied" 1
fi

## Check if RFTS/x directory exists
if [ ! -d ${RFTSD} ]; then        
        end_error "Directory ${RFTSD} doesn't exist" 1
fi

## Check if work director exists
if [ ! -d ${RFTSW} ]; then
        end_error "Directory ${RFTSW} doesn't exist" 1
fi

## Begin
begin
echo "Data are being collected, please wait..."

## Compute archive name
rfts_archive="${OUTPUT}/${now}_#_${rfts_id}#_#${MyHOST}.tar"

## Change to RFTS home directory
echo "Collect RFTS/x configuration"
cd ${RFTSD}

## Tar config
tar -cf ${rfts_archive} config/nci.cfg
tar -rf ${rfts_archive} config/rfts.cfg
## Tar sideinfos
echo "Collect RFTS/x sideinfo"
tar -rf ${rfts_archive} config/sideinfo.cfg
## Tar basket (old format)
if [ -f config/basket.cfg ];then
	echo "Collect RFTS/x basket.cfg"
	tar -rf ${rfts_archive} config/basket.cfg
fi
cd config/
## Tar resourceManagerConfig.xml
if [ -f config/settings/resourceManagerConfig.xml ];then
	cp config/settings/resourceManagerConfig.xml ./config/
	tar -rf ${rfts_archive} config/resourceManagerConfig.xml
	rm config/resourceManagerConfig.xml
fi
## Tar baskets
echo "Collect RFTS/x baskets"
find baskets -exec tar -rf ${rfts_archive} {} \;
## Tar events
echo "Collect RFTS/x events"
find events -exec tar -rf ${rfts_archive} {} \;

## Tar statistics infos
cd ${RFTSW}
echo "Collect RFTS/x statistics"
find archives -mtime -${retention_time} -name "*.txt" -exec tar -rf ${rfts_archive} {} \;

## Add Format Flag
echo $version > ./${format}
tar -rf ${rfts_archive} ./${format}
rm ./${format} 

## Gzip archive
gzip ${rfts_archive}

## End
echo OK
print "#========================================================="
print "# The RFTS/x configuration collection was successful"
print "# You will find the resulting exportfile here:"
print "# ${rfts_archive}"
print "#"
print "# Please send this file to the following e-Mail address: "
print "# ${email}"
print "#"
print "#========================================================="
