#!/bin/sh

#=================== HEADER ===================
# 
# 	Daimler cftspout.sh
# 	Version 2.00 - LINUX
#
# -------------------------------------------------------------------
# 
# -------------------------------------------------------------------
# 24.11.2017 - 1.00 - Initial Version
# 12.12.2017 - 1.01 - add wlog messages
# 08.01.2017 - 1.02 - bugfix
# 03.0142017 - 2.00 - Use halt/start command
# -------------------------------------------------------


### define variables
OPTIND=1
list=0
force=0
spoolout=0
cftdisp=""
ret_err=1
ret_spo=1
PRG=`basename $0`
DISPXML="/tmp/${PRG}_$$_dispcfg.xml"
success_pattern="RFXX.*"
error_pattern="RFYK-.*156.*RETRYREN"
spout_pattern="RFYR-.*"
TRKCFG="$CFTDIRRUNTIME/conf/${PRG}_trkapi.cfg"


### define functions

function show_help () {
echo 'usage: '${PRG}' [OPTION] idf=<flowidentifier>
        -h print help
		-l print details for last transfer with this IDF
		-o spool out from queue'
}

function cft_display() {
echo "
<?xml content='ascii'?>
<!-- Filter Model for the CFTUTIL DISPLAY command -->

<CFTDisplayFilter       id              = 'listcat'
			mode		= 'column'
                        title_align     = 'right'
                        default_empty   = '-'
                        default_na      = '#' >
        <Fields>
                <Field id='FDATE'       title='Date' />
                <Field id='FTIME'       title='Time' />
                <Field id='PART'        title='Partner' />
                <Field id='DIRECT'      title='Direction'       maxlength='1' suffix='' />
                <Field id='TYPE'        title='Type'            maxlength='1' suffix='' />
                <Field id='PHASE'       title='Phase'           maxlength='1' suffix='' />
                <Field id='PHASESTEP'   title='Phasestep'       maxlength='1' suffix='' />
                <Field id='ACK'         title='Ack'             maxlength='1' suffix=' '/>
                <Field id='IDF'         title='IDF'             minlength='4' />
                <Field id='IDT'         title='IDT'     />
                <Field id='IDTU'        title='IDTU'    />
                <Field id='DIAGI'       title='Diagi'   />
                <Field id='DIAGP'       title='Diagp'   />
		<Field id='FNAME'	title='Fname'	/>
		<Field id='FTNAME'	title='Wfname'	/>
		<Field id='EXEC'	title='PostProc'/>
		<Field id='TRKR'	title='CycleID' />
                <Field id='RPART'       title='Receiver' />
        </Fields>
</CFTDisplayFilter>
" >${DISPXML}
if [[ $1. == error. ]];then
	cftutil display idf=${idf}, SORTBY=IDT, DIRECT=RECV, PHASE=Y, fmodel=${DISPXML}
else
	sleep 2
	cftutil display idf=${idf}, idt=$2, DIRECT=RECV, fmodel=${DISPXML}
fi

#cftutil display sortby=IDT, fmodel=${DISPXML};
}

read_val () {
cftdisp=(`cft_display error | sed -n '2p' | sed "s/CP NONE/CP-NONE/" | tr " " "\n"`)
fdate=`echo ${cftdisp[0]}`
ftime=`echo ${cftdisp[1]}`
part=`echo ${cftdisp[2]}`
dtcaspp=`echo ${cftdisp[3]}`
#idf=`echo ${cftdisp[4]}`
idt=`echo ${cftdisp[5]}`
idtu=`echo ${cftdisp[6]}`
diagi=`echo ${cftdisp[7]}`
diagp=`echo ${cftdisp[8]}`
fname=`echo ${cftdisp[9]}`
wfname=`echo ${cftdisp[10]//+}`
ppexec=`echo ${cftdisp[11]}`
cycleid=`echo ${cftdisp[12]}`
rpart=`echo ${cftdisp[13]}`

#if no absolute path was configured add CFTDIRRUNTIME to file path
echo "${fname}"  | grep "^/" >/dev/null 2>&1; ret=$?; if [ ${ret} -ne 0 ]; then fname=${CFTDIRRUNTIME}/$fname; fi
echo "${wfname}" | grep "^/" >/dev/null 2>&1; ret=$?; if [ ${ret} -ne 0 ]; then wfname=${CFTDIRRUNTIME}/$wfname; fi
}

read_val_success(){

cftdisp=(`cft_display success ${idt} | sed -n '2p' | sed "s/CP NONE/CP-NONE/" | tr " " "\n"`)
fdate=`echo ${cftdisp[0]}`
ftime=`echo ${cftdisp[1]}`
part=`echo ${cftdisp[2]}`
dtcaspp=`echo ${cftdisp[3]}`
echo $dtcaspp
#idf=`echo ${cftdisp[4]}`
idt=`echo ${cftdisp[5]}`
idtu=`echo ${cftdisp[6]}`

}

print_list () {
echo "Date:       ${fdate}"
echo "Time:       ${ftime}"
echo "Partner:    ${part}"
echo "DTCASPP:    ${dtcaspp}"
echo "IDF:        ${idf}"
echo "IDT:        ${idt}"
echo "IDTU:       ${idtu}"
echo "Diagi:      ${diagi}"
echo "Diagp:      ${diagp}"
echo "Fname:      ${fname}"
echo "Wfname:     ${wfname}"
echo "PostProc:   ${ppexec}"
#echo "CycleID:    ${cycleid}"
#echo "Receiver:   ${rpart}"
}

check_status () {
echo "${cftdisp[*]}" | grep "${error_pattern}" >/dev/null 2>&1; ret_err=$?
echo "${cftdisp[*]}" | grep "${spout_pattern}" >/dev/null 2>&1; ret_spo=$?
if [ "${ret_err}" != "0" ] && [ "${ret_spo}" != "0" ]
then
	echo "Error: no transfer with error-code '156' or without 'ACK' found for IDF='${idf}'"; exit
fi
}

check_success () {

echo "${cftdisp[*]}" | grep "${error_pattern}" >/dev/null 2>&1; ret_err=$?
echo "${cftdisp[*]}" | grep "${spout_pattern}" >/dev/null 2>&1; ret_spo=$?
echo "${cftdisp[*]}" | grep "${success_pattern}" >/dev/null 2>&1; ret_suc=$?

if [[ "${ret_suc}" = 0 ]];then
	echo Success
else
	echo Error, check if file $fname already exists at target
fi

if [[ "${ret_err}" = "0" ]] && [[ "${ret_spo}" = "0" ]]
then
        echo "There is still files in the spool queue for IDF='${idf}'"; exit
fi

}

check_wfname () {
if [ ! -f "${wfname}" ]
then
	echo "Error: Temporary file (Wfname) '${wfname}' not found!"
	send_wlog "${PRG} Error: temporary file ${wfname} not found."
	exit
fi
}

check_spout () {
if [ "${ret_spo}" = "0" ] && [ "${spoolout}" = "0" ]
then
	echo "Error: transfer in Spool-Out Phase and Spool-Out option (-o) not set!"; exit
fi
}

cft_spout(){

# Halt Transfer
cftutil halt part=*,idf=${idf},idt=${idt} 2>&1> /dev/null
# Sleep 1 second
sleep 1
# Start Transfer
cftutil start part=*,idf=${idf},idt=${idt} 2>&1> /dev/null
echo Spool-out transfer=${idt}, flow=${idf}

}

move_file () {
if [ -f "${fname}" ] && [ "${force}" = 0 ]
then
	echo "Error: target file (Fname) '${fname}' exists and force option (-f) not set!"
	send_wlog "${PRG} Error: target file ${fname} exists."
	exit
else
	mv -f "${wfname}" "${fname}"; ret=$?
	if [ ${ret} = 0 ]
	then
		echo "File '${wfname}' was moved to '${fname}'"
		send_wlog "${PRG} OK: file ${wfname} was moved to ${fname}."
	else
		echo "Error '${wfname}' was not moved to '${fname}'"
		send_wlog "${PRG} Error: file ${wfname} was not moved to ${fname}."
		exit
	fi
fi
}

run_exec () {
CFTUTIL submit part=${part}, idf=${idf} >/dev/null 2>&1; ret=$?
if [ ${ret} = 0 ]
then
	echo "Post-Processing script '${ppexec}' successfully executed."
else
	echo "Error: Post-Processing script '${ppexec}' execution failure."
	echo "CFTUTIL error code: ${ret}"
	exit ${ret}
fi
}

send_ack () {
CFTUTIL send part=${part}, idt=${idt}, type=reply, msg="'ACK ${idt}'", idm=ACK >/dev/null 2>&1; ret=$?
if [ ${ret} = 0 ]
then
	echo "ACK sent: part=${part}, IDT=${idt}"
	echo "Post-Processing script '${ppexec}' will not be executed (manual spool-out)!"
else
	echo "Error: ACK NOT sent! part=${part}, IDT=${idt}"
	echo "CFTUTIL error code: ${ret}"
	exit ${ret}
fi
}

function create_trkcfg () {
echo TRKPRODUCTNAME=TRKUTIL > ${TRKCFG}
echo TRKLOCALADDR=`cftutil listuconf id=cft.full_hostname| head -1| cut -d '=' -f2| tr -d ' '` >> ${TRKCFG}
echo TRKTNAME=${CFTDIRRUNTIME}/data/overflow.dat >> ${TRKCFG}
echo TRK_SET_MS=0 >> ${TRKCFG}
echo TRKIPADDR=`cftutil listuconf id=sentinel.trkipaddr| head -1| cut -d '=' -f2| tr -d ' '` >> ${TRKCFG}
echo TRKIPPORT=`cftutil listuconf id=sentinel.trkipport| head -1| cut -d '=' -f2| tr -d ' '` >> ${TRKCFG}
}

function send_message () {
export TRKHOME="${CFTDIRINSTALL}/bin"
export TRKCONF="${TRKCFG}"
TRKUTIL SendEvent OBJNAME="XFBTRANSFER", CYCLEID=${cycleid}, INTERNALSTATE=1, ISEND=1, ISALERT=0, STATE=COMPLETED, ReturnCode=0, Location=${rpart}, ProductName=CFT, ReturnMessage="Manual spool-out OK"; ret=$?
}

function send_wlog () {
CFTUTIL wlog severity=w, msg="'${1}'" >/dev/null 2>&1
}


### read command line

#read options
while getopts "h?lof" opt; do
    case "$opt" in
    h|\?)
        show_help
        exit 0
        ;;
    l)  list=1
        ;;
    o)  spoolout=1
        ;;
    f)  force=1
        ;;
    esac
done

#read arguments
shift $(expr $OPTIND - 1 )
if [ $# -gt 0 ]
then
        idf=`echo ${1} | cut -d= -f2`
else
	echo "Error: missing IDF!"; show_help; exit;
fi



###main prog

#send wlog
send_wlog "${PRG} executed."

#read variables from catalog, if no transfer was found -> exit
read_val
if [ -z "${cftdisp}" ]; then echo "Error: no transfer found for IDF='${idf}'"; exit; fi

#check for list option, print listing and exit
if [ ${list} = 1 ]; then print_list; exit; fi

#check for status, if no transfer with diagi=156 or in spool-out phase -> exit
check_status


#check for spool-out, if transfer in spool-out phase and "-o" option not defined -> exit
check_spout

#execute spool-out
cft_spout

#exit
exit $ret
