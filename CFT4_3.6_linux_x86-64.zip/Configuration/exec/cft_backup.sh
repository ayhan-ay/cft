#!/bin/ksh
#=================== HEADER ===================
# 
# 	CFT Backup routine for Daimler AG
# 	Version 1.2
#	v1.1 : now backup certificates and zip archive
# 	v1.2 : now backup objects in different files
#		   now backup Copilot authentication files
# 	       send backup file to a remote CFT
#

# Timestamp
now=`date +"%y%m%d_%H%M"`

# Define Archive duration
tarchive=`echo &PARM | cut -d" " -f1`
if [ ${#tarchive} -eq 0 ]; then
   tarchive=30
fi
# CFT Name
cftname=`cftuconf cft.instance_id`
# Bkup Dir
bkupdir=$CFTDIRBACKUP
# Bkup file
bkfile=${bkupdir}/${now}_${cftname}_backup

# Archive the current CFT configuration
cftutil cftext type=all, fout=$bkupdir/${now}_cftall.bak
cftutil cftext type=part, fout=$bkupdir/${now}_cftpart.bak
cftutil cftext type=dest, fout=$bkupdir/${now}_cftpart.bak
cftutil cftext type=tcp, fout=$bkupdir/${now}_cftpart.bak
cftutil cftext type=send, fout=$bkupdir/${now}_cftflow.bak
cftutil cftext type=recv, fout=$bkupdir/${now}_cftflow.bak

# Export PKI content
cd $bkupdir
PKIUTIL pkiext fout=${now}_pki.bak

# Copy xfbadm config file (used for API server/Copilot) access 
cp $CFTDIRRUNTIME/conf/passwd $bkupdir/.
cp $CFTDIRRUNTIME/conf/group $bkupdir/.

# Tar and gzip
tar -cvf ${bkfile}.tar *.bak USER* ROOT* passwd group
gzip ${bkfile}.tar

# Remove files from backup dir which are not archive
find $bkupdir -type f -name "*.bak" -exec rm {} \;
find $bkupdir -type f -name "USER*" -exec rm {} \;
find $bkupdir -type f -name "ROOT*" -exec rm {} \;
find $bkupdir -type f -name "passwd" -exec rm {} \;
find $bkupdir -type f -name "group" -exec rm {} \;

# Remove Older archives
if [ $? -eq 0 ]; then
	find $bkupdir -type f -name "*.tar.gz" -mtime +$tarchive -exec rm {} \;
fi

# Send file to a remote CFT (Data collection CFT)
part=`cftuconf samples.bkpart.value`
idf=`cftuconf samples.bkidf.value`

if [ ${#part} -gt 0 ] && [ ${#idf} -gt 0 ] && [ -f ${bkfile} ];then
	cftutil send part=${part}, idf=${idf}, fname=${bkfile}.tar.gz
fi

#Delete Cron script
rm $0
rm $0.err	