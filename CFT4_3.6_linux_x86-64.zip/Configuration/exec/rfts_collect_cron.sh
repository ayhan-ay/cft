#!/bin/ksh

#=================== HEADER ===================
# 
# 	RFTS Collect for CFTCRON Daimler AG
# 	Version 1.1
#   v1.1 : collect basket cfg format
#
# Call only over CFTCRON
# rfts_collect.sh RFTSD=<RFTS installation folder> OUTPUT=<archive_output_folder>
# <RFTS installation folder> : Absolute path to the RFTS/x installation folder containing the config subdirectory
# <archive_output_folder> : Output folder for the file created
#

version="1.0"
now=`date +"%Y%m%d-%H%M"`
protocol="rfts_collect.prot"
PERIOD=10
format=RFTS_ASSESSMENT_FORMAT_1
MyHOST=`hostname`
PARAMS="&PARM"

usage()
{
        exit_code=${2:-0}
        if [ ! -z "$1" -a _ != "$1" ] ; then
                echo " "
                echo "$0: $1"
        fi
        cat << EOFUSAGE

Usage: $0 [-h] RFTSD=... OUTPUT=...

Options:
  -h: Display this usage message

Parameters:
  RFTSD:           Absolute path to the RFTS/x Home folder containing the config directory
  OUTPUT:          Output folder for the RFTS/x archive (tar.gz)

EOFUSAGE
        exit $exit_code
} # EOP usage

begin(){

        print
        print "#========================================================="
        print "#====== RFTS collect for Daimler ========================="
        print "#====== Version $version ======================================"
        print "#========================================================="
        print "#========================================================="

}

end_error (){

print "#========================================================="
print "#====== RFTS collect for Daimler ========================="
print "#====== Version $version ======================================"
print "#====== $1"
print "#====== No archive has been generated, exit $2"
print "#========================================================="
exit $2

}
# ====================================================================
#                              M A I N
# ====================================================================
# Scan Parameters name=value (starting without '-')
# Get CFT from CFTCRON
echo $PARAMS
echo PARM LENGTH=${#PARAMS}
RFTSD=`echo $PARAMS| cut -d";" -f1 | cut -d"=" -f2`;
OUTPUT=`echo $PARAMS| cut -d";" -f2 | cut -d"=" -f2`;
PERIOD=`echo $PARAMS | cut -d";" -f3 | cut -d"=" -f2`;

## Retrieve parameter file
RFTSC=${RFTSD}/config/rfts.cfg

## check if rfts.cfg path is correct and exist otherwise exit
if [ ! -r ${RFTSC} ];then
        end_error "The RFTSx configuration file ${RFTSC} doesn't exist" 1
fi

## Check if we have the RFTS/x ID otherwise exit
rfts_id=`grep -i RFTS_ID ${RFTSC} |cut -d= -f2`
if [ ${rfts_id}. == . ];then
        end_error "The RFTS-ID could not be computed" 1        
fi

## Compute RFTS Work folder
RFTSW=`grep -i RFTS_WORK_PATH ${RFTSC} |cut -d= -f2`
if [ ! -r ${RFTSW} ];then
        end_error "The ${RFTSW} work folder doesn't exist or permission is denied" 1
fi

## Compute RFTS Log folder
RFTSL=${RFTSW}/log
if [ ! -r ${RFTSL} ];then
        end_error "The ${RFTSL} folder doesn't exist or permission is denied" 1
fi

## Check if RFTS/x directory exists
if [ ! -d ${RFTSD} ]; then        
        end_error "Directory ${RFTSD} doesn't exist" 1
fi

## Check if work director exists
if [ ! -d ${RFTSW} ]; then
        end_error "Directory ${RFTSW} doesn't exist" 1
fi

## Begin
begin
echo "Data are being collected, please wait..."

## Compute archive name
rfts_archive="${OUTPUT}/${now}_#_${rfts_id}#_#${MyHOST}.tar"

## Change to RFTS home directory
echo "Collect RFTS/x configuration"
cd ${RFTSD}

## Tar config
tar -cf ${rfts_archive} config/nci.cfg
tar -rf ${rfts_archive} config/rfts.cfg
## Tar sideinfos
echo "Collect RFTS/x sideinfo"
tar -rf ${rfts_archive} config/sideinfo.cfg
## Tar basket (old format)
if [ -f config/basket.cfg ];then
	echo "Collect RFTS/x basket.cfg"
	tar -rf ${rfts_archive} config/basket.cfg
fi
cd config/
## Tar resourceManagerConfig.xml
if [ -f config/settings/resourceManagerConfig.xml ];then
	cp config/settings/resourceManagerConfig.xml ./config/
	tar -rf ${rfts_archive} config/resourceManagerConfig.xml
	rm config/resourceManagerConfig.xml
fi
## Tar baskets
echo "Collect RFTS/x baskets"
find baskets -exec tar -rf ${rfts_archive} {} \;
## Tar events
echo "Collect RFTS/x events"
find events -exec tar -rf ${rfts_archive} {} \;

## Tar statistics infos
cd ${RFTSW}
echo "Collect RFTS/x statistics"
find archives -mtime -${PERIOD} -name "*.txt" -exec tar -rf ${rfts_archive} {} \;

## Add Format Flag
echo $version > ./${format}
tar -rf ${rfts_archive} ./${format}
rm ./${format} 

## Gzip archive
gzip ${rfts_archive}

## wlog
CFTUTIL wlog severity=w, msg="'File collected ${rfts_archive}.gz'"

# Send file
echo send part=%uconf:samples.dcpart.value%, idf=%uconf:samples.dcidf.value%, fname=${rfts_archive}.gz > $CFTDIRRUNTIME/pub/dc.cft
cftutil @$CFTDIRRUNTIME/pub/dc.cft
rm $CFTDIRRUNTIME/pub/dc.cft

## End
echo OK
print "#========================================================="
print "# The RFTS/x configuration collection was successful"
print "# You will find the resulting exportfile here:"
print "# ${rfts_archive}.gz"
print "#========================================================="

## Remove file
rm $0
if [ -f $0.err ]; then 
	rm $0.err
fi
