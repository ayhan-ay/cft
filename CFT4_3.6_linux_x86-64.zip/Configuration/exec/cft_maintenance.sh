#!/bin/ksh
#=================== HEADER ===================
# 
# 	CFT Backup routine for Daimler AG
# 	Version 1.0
#
echo nothing in this script