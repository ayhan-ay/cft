#!/bin/bash
#=================== HEADER ===================
# 
# 	Daimler - Define CFTSU rights
# 	Version 2.1
#
#	Version 1.02 :  Remove root as group
#					Change command to test CFT profile
#   Version 2.0  :  Move CFTSU outside cft installation folder
#                   Update CFT uconf accordingly
#   Version 2.1  :  Implement cftsu_update procedure for automated upgrade
#					Replace Korn shell with Bash
#					Ensure Script is executed with root user
#
#   Execute as root
#
#   https://docs.axway.com/bundle/TransferCFT_38_UsersGuide_allOS_en_HTML5/page/Content/UNIX/t_adding_system_user_unix.htm
#

# Load CFT Profile first
dirname=`dirname $0`
if [[ ! -f $dirname/../profile ]];then
	echo "CFT Profile not found in $dirname/../profile, exit"
	echo "Check the CFT Installation"
	exit 1
else
	. $dirname/../profile
fi

# Check if current user is root, otherwise abort
if [ "$EUID" -ne 0 ]
  then echo "Please execute this script run as root user"
  exit 1
fi

# Define CFTSU folder
CFTSU_process=$CFTDIRINSTALL/../../sucft/CFTSU
# Define CFT User
CFT_user=`CFTUTIL /M=40 uconfget id=am.passport.superuser| cut -d"=" -f2`

echo 
echo 1. - Create su Folder in case not existing, and copy CFTSU file
CFTSU_folder=`dirname ${CFTSU_process}`
if [[ ! -d ${CFTSU_folder} ]];then
	su - ${CFT_user} -c "mkdir ${CFTSU_folder}"
	su - ${CFT_user} -c "cp $CFTDIRINSTALL/bin/CFTSU ${CFTSU_process}"
	rc3=$?
fi

echo 
echo 2. - Update CFT Unified Configuration with user ${CFT_user}
CFTSU_process=`realpath ${CFTSU_process}`
su - ${CFT_user} -c ". $CFTDIRRUNTIME/profile;cftutil uconfset id=cft.unix.cftsu.fname,value=${CFTSU_process}"

echo 
echo 3. - Set sticky bit for ${CFTSU_process} Process

chown root:root ${CFTSU_process}
rc=$?
chmod 555 ${CFTSU_process}
rc1=$?
chmod u+s ${CFTSU_process}
rc2=$?


echo
echo 4. - Manage cftsu_setup script for further Upgrades
cp $CFTDIRINSTALL/bin/cftsu_setup $CFTDIRRUNTIME/bin/cftsu_setup
chown root:root $CFTDIRRUNTIME/bin/cftsu_setup
chmod 555 $CFTDIRRUNTIME/bin/cftsu_setup
chmod u+s $CFTDIRRUNTIME/bin/cftsu_setup
rc4=$?

if [[ $rc -eq 0 && $rc1 -eq 0 && $rc2 -eq 0 && $rc3 -eq 0 && $rc4 -eq 0 ]];then
	ls -l ${CFTSU_process}
	echo
	echo OK
	echo
	exit 0
else
	echo
	echo Sticky bit not set, check permissions on ${CFTSU_process} AND $CFTDIRINSTALL/bin/cftsu_setup
	echo 
	exit 1
fi


