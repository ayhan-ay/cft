#!/bin/ksh

#=================== HEADER ===================
# 
# 	CFT Installation Routine 
#   Version 1.00
#
#***********************************************
# 	Change log:
# 	08.06.2021 - Version 1.00 : Initial version
# 
#***********************************************
# Usage
# 	Call :
#			$0 <Mandatory Parameter> <Optional Parameter>
#	Mandatory Parameter:
#			-i or --installdir <installdir>
#			-s or --secret <CGsecret>
#			-c or --cftname <cftname> 
#			-k or --cftkey <cftkey>
#			-a or --ipaddress <ipaddress> 
#	Optional Parameters:
#			-p or --portprefix <portprefix>
#			-g or --cghost <CGhost> 
#			-m or --cgmode <CGmode>
#
# =================== RETURN CODE =================
#	0=No error
# 	1=unknown argument
#
#=================== VARIABLES ===================
export PACKAGEDIR=$(dirname $0)
version=`cat $PACKAGEDIR/CFT4DAIMLER.txt`
CERDIR=`pwd`
now=`date +"%y-%m-%d-%H:%M"`
header="#================================ CFT Installation version $version ====================="
footer="#========================================================================================"

# Default values - replaced by command line arguments if set
# CFT Default value config
cftconfig=${PACKAGEDIR}/cft4d_config.cfg

# Central Governance Server name
export CGHOST=NONE
# Central Governance Mode (yes or no)
export CGMODE=NONE
# Central Governance Secret
export CGSECRET=NONE
# Transfer CFT Port Prefix
export PORTPREFIX=NONE
# CFT installation directory
export CFTINSTALLDIR=NONE
# CFT_ID
export CFTNAME=NONE
# CFT IP Address in CG
export IPADDRESS=NONE
# SENTINEL HOSTNAMEFULL
export SENTINELHOST=NONE
# SENTINEL PORT
export SENTINELPORT=NONE
# CFT KEY
export CFTKEY=NONE
# Local Server name (long)
export HOSTNAMESHORT=`hostname -s`
# Local Server name (short)
# Define FQDN, its different for AIX
uname -a | grep -i AIX > /dev/null
rcaix=$?
uname -a | grep -i HP-UX > /dev/null
rchpux=$?
uname -a | grep -i SunOS > /dev/null
rcsun=$?
if [ $rcaix -eq 0 ];then
	# AIX stuff 
	DOMAIN=`namerslv -s | grep domain | awk '{ print $2 }'`
	export HOSTNAMEFULL=`hostname -s`.${DOMAIN}
fi
if [[ $rchpux -eq 0 ]] || [[ $rcsun -eq 0 ]];then
	# HP-UX and Solaris stuff 
	export HOSTNAMEFULL=`hostname`
fi
if [[ ! $rchpux -eq 0  ]] && [[ ! $rcaix -eq 0 ]] && [[ ! $rcsun -eq 0 ]];then
	# Other Unixes 
	export HOSTNAMEFULL=`hostname -f`
fi 

# Configuration SAMPLES
cg_config="cg_config.cfg"
cgpki_config="cgpki_config.cfg"
dccron_config="dccron_config.cfg"
default_config="default_config.cfg"
maintcron_config="maintcron_config.cfg"
standalone_config="standalone_config.cfg"
testpki_config="testpki_config.cfg"

# Log File
PROTOCOL="${PACKAGEDIR}/cft_`hostname`_installation.prot"

# Spool-in wrapper
cftsend="cftcmd.sh"

# Change to package directory
cd $PACKAGEDIR
# Check Kernel Parameters
kernel_warning=0

#=================== FUNCTIONS ===================
#== Usage
usage(){

	rc=$1
	if [ ! $rc. = "." ];then rc=99;fi
	print $header
	print "# Transfer CFT Installation Routine for Daimler AG"
	print "# Call :"
	print "		$0 <Mandatory Parameters> [Optional Parameter]"
	print "# Mandatory Parameters:"
	print "		-i or --installdir <installdir>"
	print "		-s or --cgsecret <cgsecret>"
	print "		-c or --cftname <cftname> "
	print "		-k or --cftkey <cftkey>"
	print "		-a or --ipaddress <ipaddress> "
	print "# Optional Parameters:"
	print "		-p or --portprefix <portprefix>"
	print "		-g or --cghost <CGhost> "
	print "		-m or --cgmode <CGmode>"
	print "# Values:"
	print "		<installdir> 	: Axway product installation directory"
	print "		<cgsecret> 		: Secret used to initiate Central Governance registration"
	print "		<cftname> 		: CFT_ID"
	print "		<ipaddress>		: IP Address of the local server"
	print "		<portprefix> 	: Port Prefix"
	print "		<CGhost> 		: CG Host Name"
	print "		<CGmode> 		: yes, CG is used or no, standalone installation"
	print "# Example:"
	print "		./$0 -i /opt/axway/ -c <cft_name> -a <CG_Hostname>"
	print $footer
	exit ${rc};

}

#== Error - print and usage
error(){

print				 2>&1 | tee -a ${PROTOCOL}
print "ERROR : $1"	 2>&1 | tee -a ${PROTOCOL}
print				 2>&1 | tee -a ${PROTOCOL}
usage $2

}

#== Terminate - Successful End installation procedure
terminate(){

	print
	print "#=======================================================================================================================" 
	print "#====== CFT Installation ended successfully ============================================================================"
        print "#====== Do following steps now after successful installation============================================================"	
	print "#======  1. Execute now $CFTDIRRUNTIME/exec/cftsu.sh as root user"
	print "#======  2. Implement TransferCFT as service from $CFTDIRRUNTIME/exec/axway_cft.services"
        print "#======  3. Execute profile $CFTDIRRUNTIME/profile and Star CFT copilot with copstart for registration of CFT to CG"
	print "#======  4. Start CFT Core with cft start "
	print "#======================================================================================================================="
	print "#======================================================================================================================="
	print
	exit 0

}

#== Begin - Print header
begin(){
	print
	print "#======================================================================================================================"
	print "#====== CFT Installation for Daimler    ==============================================================================="
	print "#====== Version $version =================================================================================================="
	print "#======================================================================================================================"
	print "#======================================================================================================================"
}

#== Setdefault - Read default values from configuration file
setdefault(){

# Check Package is complete
if [[ ! -f ${cftconfig} ]];then
	print "File ${cftconfig} is missing, abort installation"
	exit 91
fi

# Read default parameters from ${cftconfig}
# Central Governance Server name
export CGHOST=`grep CGHOST ${cftconfig} | cut -d"=" -f2 | tr -d '\r'`
# Central Governance Mode (yes or no)
export CGMODE=`grep CGMODE ${cftconfig} | cut -d"=" -f2 | tr -d '\r'`
# Central Governance Secret
export CGSECRET=`grep CGSECRET ${cftconfig} | cut -d";" -f2 | tr -d '\r'`
# Central Governance Default Org
export CGORG=`grep CGORG ${cftconfig} | cut -d";" -f2 | tr -d '\r'`
# Transfer CFT Port Prefix
export PORTPREFIX=`grep PORTPREFIX ${cftconfig} | cut -d"=" -f2 | tr -d '\r'`
# CFT installation directory
export CFTINSTALLDIR=`grep CFTINSTALLDIR ${cftconfig} | cut -d"=" -f2 | tr -d '\r'`
# CFT_ID
export CFTNAME=`grep CFTNAME ${cftconfig} | cut -d"=" -f2 | tr -d '\r'`
# CFT IP Address in CG
export IPADDRESS=`grep IPADDRESS ${cftconfig} | cut -d"=" -f2 | tr -d '\r'`
# SENTINEL HOST
export SENTINELHOST=`grep SENTINELHOST ${cftconfig} | cut -d"=" -f2 | tr -d '\r'`
# SENTINEL PORT
export SENTINELPORT=`grep SENTINELPORT ${cftconfig} | cut -d"=" -f2 | tr -d '\r'`
# CFT KEY
export CFTKEY=`grep CFTKEY ${cftconfig} | cut -d"=" -f2 | tr -d '\r'`
}

#== Checkopts - Check Options from command line
checkopts(){

#evaluate command arguments
	while [[ $# -gt 1 ]]
	do
	key="$1"
	echo Option $key=$2  >> ${PROTOCOL}
	case $key in
		-i|--installdir)
		CFTINSTALLDIR="$2"
		echo CFTINSTALLDIR_USER=${CFTINSTALLDIR} >> ${PROTOCOL}
		shift # past argument
		;;
		-a|--ipaddress)
		IPADDRESS="$2"
		echo IPADDRESS_USER=${IPADDRESS} >> ${PROTOCOL}
		shift # past argument
		;;
		-p|--portprefix)
		PORTPREFIX="$2"
		shift # past argument
		;;
		-c|--cftname)
		CFTNAME="$2"
		shift # past argument
		;;
		-m|--cgmode)
		CGMODE="$2"
		shift # past argument
		;;
		-g|--cghost)
		CGHOST="$2"
		shift # past argument
		;;
		-s|--secret)
		CGSECRET="$2"
		shift # past argument
		;;
		-k|--cftkey)
		CFTKEY="$2"
		shift # past argument
		;;
		*)
		# unknown option
		usage 1			
		;;
	esac
	shift # past argument or value
	done

	# Check CFT installation directory (Mandatory)
	if [[ "$CFTINSTALLDIR" = "NONE" ]]
	then
		error "installdir (-i) is a mandatory parameter and missing"
	fi	
	
	# Check CG Mode
	if [[ ! "$CGMODE" = "yes" ]] && [[ ! "$CGMODE" = "no" ]];then
		error "Valid values for -m option (CGMode) are 'yes' or 'no'"
	fi
	
	# Check CG Secret
	if [[ "$CGMODE" = "yes" ]];then
		if [[ "$CGSECRET" = "NONE" || $CGSECRET. = . ]]
		then
			error "cgsecret (-s) is a mandatory parameter and missing"
		fi	
	fi
	

	# Check CFT NAME
	if [[ "$CFTNAME" = "NONE" ]]
	then
		message="CFTNAME (-c) is mandatory parameter and missing "
		error "${message}" 3
	fi
	
	# Check CFT IP ADDRESS
	if [[ "$IPADDRESS" = "NONE" ]];
	then
	              message="IPADDRESS (-a) is mandatory parameter and missing "
                      error "${message}" 
	fi
	
	# Check CG Mode
	if [[ ! "${CGMODE}" = "no" && ! "${CGMODE}" = "yes" ]]
	then
		error "CG Mode should be yes or no. Default is yes" 
	fi
	
	# Check License Key
	if [[ ${CFTKEY} = "NONE" || ${CFTKEY}. = . ]]
	then
		error "No License Key provided, please provided one using the -k option" 
	fi
	
	# Check CG Host
	if [[ ${CGHOST} = "NONE" || ${CGHOST}. = . ]]
	then
		error "No Central Governance Hostname provided, please provided one using the -g option" 
	fi
	
	# Check Sentinel Host
	if [[ ${SENTINELHOST} = "NONE" ]]
	then
		SENTINELHOST=${CGHOST} 
	fi
}

#=================== MAIN ===================
begin 2>&1 | tee -a ${PROTOCOL}
# Set default parameters
echo "## Default values and Input parameters" 2>&1 >> ${PROTOCOL}
setdefault
# Check input parameters
checkopts $*

# Fix Carriage return for CFT_NAME and IP ADDRESS
CFTNAME=`echo ${CFTNAME} | tr -d '\r'`
IPADDRESS=`echo ${IPADDRESS} | tr -d '\r'`
export CFTINSTALLDIR
#proceed with CFT installation
echo Install CFT in : $CFTINSTALLDIR/cft 2>&1 | tee -a ${PROTOCOL}
echo CGMODE : $CGMODE 2>&1 | tee -a ${PROTOCOL}
echo CFT NAME is : $CFTNAME 2>&1 | tee -a ${PROTOCOL}
echo Port prefix : $PORTPREFIX  2>&1 | tee -a ${PROTOCOL}
if [[ $CGMODE. = yes. ]];then
	echo IP for CG registration is : $IPADDRESS 2>&1 | tee -a ${PROTOCOL}
	echo CG Hostname is : $CGHOST 2>&1 | tee -a ${PROTOCOL}
	echo Sentinel Hostname is : $SENTINELHOST 2>&1 | tee -a ${PROTOCOL}
	echo Sentinel Port is : $SENTINELPORT  2>&1 | tee -a ${PROTOCOL}
fi
echo CFT Key is : $CFTKEY 2>&1 | tee -a ${PROTOCOL}

# Start CFT Installation
echo "## Start Installation" 2>&1 >> ${PROTOCOL} 
echo Start CFT Silent setup 2>&1 | tee -a ${PROTOCOL}
echo "## Start CFT Silent Installation" 2>&1 >> ${PROTOCOL}
silent_file_cft=initialize.properties
service_file=axway_cft.services
cp ${PACKAGEDIR}/silent/${silent_file_cft}.bkp ${silent_file_cft}
mv ${silent_file_cft} ${silent_file_cft}.org
sed -e "s#INSTANCE_CFTNAME#${CFTNAME}#g" \
    -e "s#CFT_INSTALLDIR#${CFTINSTALLDIR}#g" \
    -e "s#PACKAGEDIR#${CERDIR}#g" \
    -e "s#IP_ADDRESS#${IPADDRESS}#g" \
    -e "s#PREFIXPORT#${PORTPREFIX}#g" \
    -e "s#CFTKEY#${CFTKEY}#g" \
    -e "s#CG_HOST#${CGHOST}#g" \
    -e "s#CG_SECRET#${CGSECRET}#g" \
     < ${silent_file_cft}.org >>${silent_file_cft}
cp ${PACKAGEDIR}/Configuration/exec/axway_cft.services.bkp ${PACKAGEDIR}/Configuration/exec/axway_cft.services
mv ${PACKAGEDIR}/Configuration/exec/axway_cft.services ${PACKAGEDIR}/Configuration/exec/axway_cft.services.org
sed -e "s#CFT_INSTALLDIR#${CFTINSTALLDIR}#g" < ${PACKAGEDIR}/Configuration/exec/axway_cft.services.org >>${PACKAGEDIR}/Configuration/exec/axway_cft.services 

./Transfer_CFT_3.6_SP3_linux-x86-64_BN13452000.run --mode unattended --conf-file initialize.properties
RC=$?
echo
echo "!! CFT Installation RC=$RC" 2>&1 >> ${PROTOCOL}
echo CFT Installation terminated with RC=$RC 2>&1 | tee -a ${PROTOCOL}
if [ $RC -ne 0 ];then
	error "CFT Silent Installation Failed, abort deployment"
fi

# Start Customization
echo CFT installation - now Customize... 2>&1 | tee -a ${PROTOCOL}

# Load CFT Profile
echo "## Load profile from $CFTINSTALLDIR/cft/runtime" 2>&1 >> ${PROTOCOL}
. $CFTINSTALLDIR/cft/runtime/profile
sleep 1

echo Import default configuration 2>&1 | tee -a ${PROTOCOL}
# Create spool directory in runtime/spool
echo "## Create spool directory in $CFTDIRRUNTIME/spool" 2>&1 >> ${PROTOCOL}
mkdir $CFTDIRRUNTIME/spool
echo "!! Return code of create spool directory was $?" 2>&1 >> ${PROTOCOL}

# Create backup folder for the configuration
echo "## Create backup directory in $CFTDIRRUNTIME/backup" 2>&1 >> ${PROTOCOL}
mkdir $CFTDIRRUNTIME/conf/backup
echo "!! Return code of create backup directory was $?" 2>&1 >> ${PROTOCOL}

# Copy sample configuration, exec and certificates
echo "## Copy Exec files and Samples in the runtime folder" 2>&1 >> ${PROTOCOL}
cp -R Configuration/* $CFTDIRRUNTIME/
cp Configuration/conf/DEUTSCH* $CFTDIRRUNTIME/pub
cp Configuration/conf/FRENCH $CFTDIRRUNTIME/pub
rm $CFTDIRRUNTIME/exec/cftcmd*
rm $CFTDIRRUNTIME/exec/cftspout*
# Copy custom cftsend for spool capabilites
echo "## Copy ${cftsend} file in the $CFTDIRRUNTIME/bin/ folder" 2>&1 >> ${PROTOCOL}
uname -a | grep AIX > /dev/null
if [ $? -eq 0 ];then
	cp -R Configuration/exec/${cftsend}.aix $CFTDIRRUNTIME/bin/cftcmd
fi
uname -a | grep -i Linux > /dev/null
if [ $? -eq 0 ];then
	cp -R Configuration/exec/${cftsend}.linux $CFTDIRRUNTIME/bin/cftcmd
fi

# Copy cftspout script
cp -R Configuration/exec/cftspout.sh $CFTDIRRUNTIME/bin/cftspout
chmod 500 $CFTDIRRUNTIME/bin/cftspout

# Remove Default PKI and recreate a new one
rm $CFTPKU 2>&1 >> ${PROTOCOL}
rm $CFTPKU.idx 2>&1 >> ${PROTOCOL}
PKIUTIL pkifile fname = '$CFTPKU', mode = 'CREATE'  2>&1 >> ${PROTOCOL}

# Define Sample values from Environment variables
# Setup CFT sample configuration 
# Set IP range according to the parameters */
cftutil uconfset id=samples.pesitany_sap.value,value=${PORTPREFIX}61 2>&1 >> ${PROTOCOL}
cftutil uconfset id=composer.local_port,value=${PORTPREFIX}61 2>&1 >> ${PROTOCOL}
cftutil uconfset id=samples.pesitssl_sap.value,value=${PORTPREFIX}62 2>&1 >> ${PROTOCOL}
cftutil uconfset id=samples.coms_port.value,value=${PORTPREFIX}65 2>&1 >> ${PROTOCOL}
cftutil uconfset id=copilot.general.serverport,value=${PORTPREFIX}66	 2>&1 >> ${PROTOCOL}
cftutil uconfset id=copilot.general.ssl_serverport,value=${PORTPREFIX}67	 2>&1 >> ${PROTOCOL}
# Add coms host as sample value */
cftutil uconfset id=samples.coms_host.value, value=127.0.0.1 2>&1 >> ${PROTOCOL}
# Add Local IP as a sample value */
cftutil uconfset id=samples.localip.value, value=${IPADDRESS} 2>&1 >> ${PROTOCOL}
# Add CG Hostname as a sample value */
cftutil uconfset id=samples.cghost.value, value=${CGHOST} 2>&1 >> ${PROTOCOL}
# Add CG Secret as a sample value */
cftutil uconfset id=samples.cgsecret.value, value=${CGSECRET} 2>&1 >> ${PROTOCOL}
# Add CG Default Organization */
cftutil uconfset id=samples.cgorg.value, value="'${CGORG}'" 2>&1 >> ${PROTOCOL}
# Add CG Mode */
cftutil uconfset id=samples.cgmode.value, value=${CGMODE} 2>&1 >> ${PROTOCOL}
# Add coms_host as sample value */
cftutil uconfset id=samples, value="'coms_port coms_host pesitany_sap pesitssl_sap localip cghost cgsecret cgorg cgmode'" 2>&1 >> ${PROTOCOL}

# Import Default configuration according to CGMODE
if [[ "${CGMODE}" = "yes" ]];then
	echo "Setup Central Governance Connectivity" 2>&1 | tee -a ${PROTOCOL}
	echo "## Import $CFTDIRRUNTIME/conf/${default_config} default configuration ##" 2>&1 >> ${PROTOCOL}
	# Import CG Parameters
	CFTUTIL @$CFTDIRRUNTIME/conf/${cg_config} 2>&1 >> ${PROTOCOL}
	# Import CG Governance CA certificate
	echo "## Import $CFTDIRRUNTIME/conf/${cgpki_config} CG Governance CA ##" 2>&1 >> ${PROTOCOL}
	PKIUTIL @$CFTDIRRUNTIME/conf/${cgpki_config} 2>&1 >> ${PROTOCOL}
	RC1=$?
	# Import Default configuration
	echo "## Import $CFTDIRRUNTIME/conf/${default_config} default configuration ##" 2>&1 >> ${PROTOCOL}
	cftutil @$CFTDIRRUNTIME/conf/${default_config} 2>&1 >> ${PROTOCOL}
	RC=$?
fi
# CG Mode=no : Standalone mode for external partners or testing purposes
if [[ "${CGMODE}" = "no" ]];then
	# Import standalone configuration
	echo "## Import $CFTDIRRUNTIME/conf/${standalone_config} default configuration ##" 2>&1 >> ${PROTOCOL}
	cftutil @$CFTDIRRUNTIME/conf/${standalone_config} 2>&1 >> ${PROTOCOL}
	RC=$?
	# Import Default certificates for testing purposes
	echo "## Import $CFTDIRRUNTIME/conf/daimler-testpki_config.cfg default certificates ##" 2>&1 >> ${PROTOCOL}
	PKIUTIL @$CFTDIRRUNTIME/conf/${testpki_config} 2>&1 >> ${PROTOCOL}
	RC1=$?
fi
echo "## Return code of update config was RC=$RC" 2>&1 >> ${PROTOCOL}
echo "## Return code of update PKI was RC=$RC1" 2>&1 >> ${PROTOCOL}

# Activate CG Connector or not
if [[ "${CGMODE}" = "yes" ]];then
	echo "Enable Central Governance Connectivity" 2>&1 | tee -a ${PROTOCOL}
	cftutil uconfset id=cg.enable,value=yes 2>&1 >> ${PROTOCOL}
	# Sentinel Parameters
	cftutil uconfset id=sentinel.trkproductipaddr, value=${SENTINELHOST} 2>&1 >> ${PROTOCOL}
	cftutil uconfset id=sentinel.trkipport, value=${SENTINELPORT} 2>&1 >> ${PROTOCOL}
fi
if [[ "${CGMODE}" = "no" ]];then
	echo "Disable Central Governance Connectivity" 2>&1 | tee -a ${PROTOCOL}
	cftutil uconfset id=cg.enable,value=no 2>&1 >> ${PROTOCOL}
fi

# Import Maintenance CRON
cftutil @$CFTDIRRUNTIME/conf/${maintcron_config} 2>&1 >> ${PROTOCOL}

# Create Flag file with environment variables (usr profile)
echo Create User profile 2>&1 | tee -a ${PROTOCOL}
usrprofile=$CFTDIRRUNTIME/profile.d/usrprofile
echo "## Create User profile $usrprofile" 2>&1 >> ${PROTOCOL}
if [ -f $usrprofile ];then
  rm $usrprofile
fi
if [ ! -f $usrprofile ]
then
	echo "#" > $usrprofile
	echo "# Axway Transfer CFT for Daimler AG" >> $usrprofile
	echo "# The installation was executed on $now" >> $usrprofile
	echo "# Version=$version" >> $usrprofile
	echo "#" >> $usrprofile
	echo 'echo \$CFTDIRRUNTIME' = $CFTDIRRUNTIME >> $usrprofile
        echo 'export CFTDIRSPOOL=$CFTDIRRUNTIME/spool' >> $usrprofile	
	echo 'export CFTDIRBACKUP=$CFTDIRRUNTIME/conf/backup' >> $usrprofile
	echo 'export CFTSPOOLDEBUG=0' >> $usrprofile
	echo 'export CFTSPOOLDEFAULT='$CFTSPOOLDEFAULT >> $usrprofile
	echo 'export CFTSYNCHDEFAULT='$CFTSYNCHDEFAULT >> $usrprofile
	echo 'export CFT4DAIMLER='$version >> $usrprofile	
fi

# Change right on the CFT directories
echo "## Setup user and group rights" 2>&1 >> ${PROTOCOL}
chmod -R 750 $CFTDIRINSTALL 2>&1 >> ${PROTOCOL}
chmod -R 750 $CFTDIRRUNTIME 2>&1 >> ${PROTOCOL}

# Only CFT user may start and stop CFT
chmod 700 $CFTDIRINSTALL/bin/cftstart 2>&1 >> ${PROTOCOL}
chmod 700 $CFTDIRINSTALL/bin/cftstop 2>&1 >> ${PROTOCOL}

# Only CFT user and Group user may create transfer requests
chmod 770 $CFTCOM 2>&1 >> ${PROTOCOL}
chmod 770 $CFTDIRRUNTIME/bin/cftcmd

# cftutil about
echo "## Print System information" 2>&1 >> ${PROTOCOL}
cftutil about 2>&1 >> ${PROTOCOL}

# Copy protocol file in CFT folder
cp ${PROTOCOL} ${CFTDIRRUNTIME}/log/. 2>&1 >> ${PROTOCOL}

# Terminate customization
echo CFT installation initial customization Finished 2>&1 | tee -a ${PROTOCOL}

# End installation
terminate 2>&1 | tee -a ${PROTOCOL}
#=================== END ===================
