#!/bin/sh

SYNCHRONY_DIR="$1"
PACKAGE_FNAME="$2"

# change Libpath for cftunzip and libz.so
LD_LIBRARY_PATH="copupd/boot:$LD_LIBRARY_PATH"
export LD_LIBRARY_PATH;
LIBPATH="copupd/boot:$LD_LIBRARY_PATH"
export LIBPATH;

CFTUNZIP="copupd/boot/cftunzip"
UNZIPDIR="copupd/download/p"

e_r_r_o_r()
{
    if [ "$2" != "" ]; then echo "ERROR -- $2"; fi
    exit $1
}

if [ "$PACKAGE_FNAME" = "" ]; then e_r_r_o_r 2 "PACKAGE_FNAME (arg 1) is missing or empty."; fi
if [ "$SYNCHRONY_DIR" = "" ]; then e_r_r_o_r 2 "SYNCHRONY_DIR (arg 2) is missing or empty."; fi

if [ ! -d "$SYNCHRONY_DIR" ]; then e_r_r_o_r 1 "$SYNCHRONY_DIR does not exist or is not a directory."; fi

unset DISPLAY

# gives right to the exec
CHMODUX="chmod u+x $CFTUNZIP"
eval $CHMODUX

# unzip $PACKAGE_FNAME
UNZIP_CMD="$CFTUNZIP $PACKAGE_FNAME -d $UNZIPDIR"
echo $UNZIP_CMD
eval "$UNZIP_CMD"
rc="$?"
if [ "$rc" != "0" ]; then e_r_r_o_r $rc "Command execution problem (Can't unzip $PACKAGE_FNAME)."; else echo "Command successful."; fi

EXECUTABLE=`ls $UNZIPDIR/*.run`

# gives right to the run
CHMODRUN="chmod u+x $EXECUTABLE"
eval $CHMODRUN

# launch run form $PACKAGE_FNAME
UP_CMD="$EXECUTABLE --mode unattended --installdir $SYNCHRONY_DIR"
eval "$UP_CMD"
rc="$?"
if [ "$rc" != "0" ]; then 
    if [ -d "$UNZIPDIR" ]; then rm -Rf $UNZIPDIR; fi
    e_r_r_o_r $rc "Command execution problem (Can't exec run)."; 
else 
    echo "Command successful."; 
fi

# del $UNZIPDIR
DELDIR="rm -rf $UNZIPDIR"
eval "$DELDIR"
rc="$?"
if [ "$rc" != "0" ]; then e_r_r_o_r $rc "Command execution problem (Can't delete $UNZIPDIR)."; else echo "Command successful."; fi

exit "$rc"
